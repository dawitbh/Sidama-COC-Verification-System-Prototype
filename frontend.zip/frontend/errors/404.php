<?php
/*
 * Project: COC Verification system for sidama region
 * Purpose: Master's Degree Thesis 
 * * Description: This software was developed to solve a real-world problem as part of 
 * the graduation requirements for the Master's Program.
 * * Author: Dawit Birru Hurisso
 * Institution: Czech University of Life Sciences Prague (CZU)
 * Graduate Year: 2026
 */
if (!isset($title)) $title = '404 — Not Found';
if (!isset($message)) $message = 'The requested resource could not be found.';
if (!isset($actionText)) $actionText = 'Go home';
if (!isset($actionLink)) $actionLink = '/';
if (!isset($hint)) $hint = '';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?></title>
<style>
:root{--bg:#fbfbfd;--card:#fff;--muted:#6b7280;--accent:#0b63c6}
html,body{height:100%;margin:0;font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,"Helvetica Neue",Arial}
body{display:flex;align-items:center;justify-content:center;background:linear-gradient(180deg,#fff 0%,var(--bg) 100%);padding:24px}
.card{max-width:760px;width:100%;background:var(--card);border-radius:12px;box-shadow:0 10px 30px rgba(2,6,23,0.08);padding:32px;text-align:center}
.h1{font-size:22px;margin:0 0 8px}
.p{color:var(--muted);margin:0 0 16px}
.actions{display:flex;gap:12px;justify-content:center;margin-top:18px}
.btn{display:inline-block;padding:10px 16px;border-radius:8px;text-decoration:none;color:#fff;background:var(--accent)}
.btn-secondary{background:#6b7280}
.hint{margin-top:12px;color:#9aa4b2;font-size:13px}
@media(max-width:480px){.card{padding:20px}}
</style>
</head>
<body>
<div class="card" role="alert">
  <h1 class="h1"><?= htmlspecialchars($title) ?></h1>
  <p class="p"><?= htmlspecialchars($message) ?></p>
  <div class="actions">
    <?php if ($actionLink): ?><a class="btn" href="<?= htmlspecialchars($actionLink) ?>"><?= htmlspecialchars($actionText) ?></a><?php endif; ?>
    <a class="btn btn-secondary" href="/">Home</a>
  </div>
  <?php if ($hint): ?><div class="hint"><?= htmlspecialchars($hint) ?></div><?php endif; ?>
</div>
</body>
</html>