/* flags-wave.js — simple, robust floating animation for header flags
   Falls back to CSS keyframes when JS is unavailable. Keeps motion light and responsive. */
(function () {
  function initFlags() {
    const wraps = Array.from(document.querySelectorAll('.header-flags .flag-wrap'));
    if (!wraps.length) return;

    const items = wraps.map((w, idx) => {
      const img = w.querySelector('.flag-img');
      const phase = Math.random() * Math.PI * 2;
      const amp = 4 + Math.random() * 6; // px
      const speed = 0.0025 + Math.random() * 0.0035;
      const state = { w, img, phase, amp, speed, hover: false };

      w.addEventListener('mouseenter', () => { state.hover = true; });
      w.addEventListener('mouseleave', () => { state.hover = false; });
      return state;
    });

    let last = performance.now();
    function loop(now) {
      const dt = now - last;
      last = now;
      items.forEach((it, i) => {
        if (!it.img) return;
        // use time-based phase for smooth motion
        const t = now * it.speed + it.phase;
        const sway = Math.sin(t) * it.amp * (it.hover ? 1.6 : 1);
        const rot = Math.sin(t * 0.6 + it.phase * 0.4) * (it.amp * 0.12) * (it.hover ? 1.2 : 1);
        const scale = it.hover ? 1.03 : 1;
        it.img.style.transform = `translateY(${sway.toFixed(2)}px) rotate(${rot.toFixed(2)}deg) scale(${scale})`;
      });
      requestAnimationFrame(loop);
    }
    requestAnimationFrame(loop);
  }

  // init on DOM ready; also re-run when new header may be injected
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initFlags);
  } else {
    initFlags();
  }
})();
