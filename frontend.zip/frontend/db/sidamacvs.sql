-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2026 at 09:05 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sidamacvs`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(100) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `updationDate` timestamp NULL DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `UserName`, `Password`, `updationDate`, `role_id`) VALUES
(1, 'admin', '$2y$10$jblZ6cVL.A9QlumYEdQBYOXBZyDTCk7t8v.FSabMEg670Xfrbsxqa', '2020-06-11 12:26:07', 1),
(4, 'da', '$2y$10$aKEE5T38CxLE.rxAGFZduOH/Q6mBSbyoS34SGlEIxTUnrlK.YX3kG', NULL, 3),
(5, 'daw', '$2y$10$bWloYAMlHzXeZfgJVAioHe325PqDcD.TVM01NaqBmOVVeBOOIQnzW', NULL, 4),
(15, 'dawit', '$2y$10$g6.Aqun/bIgJRl2zQoQwROYLscajHGfMNzKZ87o96M.ApXXvWbeZ6', NULL, 2);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `description`) VALUES
(1, 'super_admin', 'Full control'),
(2, 'admin', 'Manage certificates and uploads'),
(3, 'data_entry', 'Can upload and edit certificates'),
(4, 'viewer', 'Read-only');

-- --------------------------------------------------------

--
-- Stand-in structure for view `students_excel`
-- (See below for the actual view)
--
CREATE TABLE `students_excel` (
`student_id` int(11)
,`certificate_number` varchar(100)
,`name_of_candidate` varchar(100)
,`occupation` varchar(255)
,`level` varchar(100)
,`issued_on` date
,`valid_until` date
,`assessment_center` varchar(255)
,`control_no` varchar(100)
,`status` int(1)
);

-- --------------------------------------------------------

--
-- Table structure for table `tblclasses`
--

CREATE TABLE `tblclasses` (
  `id` int(100) NOT NULL,
  `ClassName` varchar(100) DEFAULT NULL,
  `ClassNameNumeric` int(100) NOT NULL,
  `Section` varchar(100) NOT NULL,
  `CreationDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblclasses`
--

INSERT INTO `tblclasses` (`id`, `ClassName`, `ClassNameNumeric`, `Section`, `CreationDate`, `UpdationDate`) VALUES
(1, 'I(ONE)', 0, '', '2025-11-25 15:30:33', '0000-00-00 00:00:00'),
(2, 'IV', 0, '', '2026-02-18 13:23:55', '0000-00-00 00:00:00'),
(3, 'II(TWO)', 0, '', '2026-02-20 00:39:59', '0000-00-00 00:00:00'),
(4, 'III(THREE)', 0, '', '2026-02-20 00:42:25', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tblresult`
--

CREATE TABLE `tblresult` (
  `id` int(100) NOT NULL,
  `StudentId` int(100) DEFAULT NULL,
  `ClassId` int(100) DEFAULT NULL,
  `SubjectId` int(100) DEFAULT NULL,
  `marks` int(11) DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblstudents`
--

CREATE TABLE `tblstudents` (
  `StudentId` int(11) NOT NULL,
  `StudentName` varchar(100) NOT NULL,
  `RollId` varchar(100) NOT NULL,
  `StudentEmail` varchar(100) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `DOB` varchar(100) NOT NULL,
  `ClassId` int(100) DEFAULT NULL,
  `RegDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `Status` int(1) NOT NULL,
  `activation_date` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `Occupation` varchar(255) DEFAULT NULL,
  `Level` varchar(100) DEFAULT NULL,
  `Venue` varchar(255) DEFAULT NULL,
  `ControlNo` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblstudents`
--

INSERT INTO `tblstudents` (`StudentId`, `StudentName`, `RollId`, `StudentEmail`, `Gender`, `DOB`, `ClassId`, `RegDate`, `UpdationDate`, `Status`, `activation_date`, `expiry_date`, `Occupation`, `Level`, `Venue`, `ControlNo`) VALUES
(1, 'DEGIFE DEBEKO DANOLE', 'ARG-AAHS4-2021-2024-07-1000', '', '', '', 2, '2025-10-19 22:00:00', NULL, 1, '2025-10-20', '2028-10-20', 'Advanced  Animal Health Service', 'IV', 'Y/ALEM ANIMAL HEALTH', 'C.O 3591568'),
(2, 'HELEN TESFAYE MOTOSSA', 'ARG-AAHS4-2021-2024-07-1001', '', '', '', 2, '2024-10-19 22:00:00', NULL, 1, '2024-10-20', '2027-10-20', 'Advanced  Animal Health Service', 'IV', 'Y/ALEM ANIMAL HEALTH', 'C.O 3591569'),
(3, 'AYALEW ADALA TOSHE', 'ARG-AAHS4-2021-2024-07-1002', '', '', '', 2, '2023-10-19 22:00:00', '2026-03-02 11:30:43', 1, '2023-10-20', '2026-03-30', 'Advanced  Animal Health Service', 'IV', 'Y/ALEM ANIMAL HEALTH', 'C.O 3591570'),
(4, 'DINKINESH TADESE  OTE', 'ARG-AAHS4-2021-2024-07-1003', '', '', '', 2, '2023-10-19 22:00:00', '2026-03-02 11:31:41', 0, '2024-11-20', '2027-11-19', 'Advanced  Animal Health Service', 'IV', 'Y/ALEM ANIMAL HEALTH', 'C.O 3591571'),
(5, 'SHALEKA TESHOME LUTE', 'ARG-AAHS4-2021-2024-07-1004', '', '', '', 2, '2021-10-19 22:00:00', NULL, 0, '2021-10-20', '2024-10-20', 'Advanced  Animal Health Service', 'IV', 'Y/ALEM ANIMAL HEALTH', 'C.O 3591572'),
(6, 'DEGIFE AMANUEL BEKELE', 'ARG-AAHS4-2021-2024-07-1100', '', '', '', 2, '2025-10-19 22:00:00', NULL, 1, '2025-10-20', '2028-10-20', 'Advanced  Animal Health Service', 'IV', 'Y/ALEM ANIMAL HEALTH', 'C.O 3591568'),
(7, 'HELEN TADESSE MAMO', 'ARG-AAHS4-2021-2024-07-1201', '', '', '', 2, '2024-10-19 22:00:00', NULL, 1, '2024-10-20', '2027-10-20', 'Advanced  Animal Health Service', 'IV', 'Y/ALEM ANIMAL HEALTH', 'C.O 3591569'),
(8, 'AYELE ADALA TESEMA', 'ARG-AAHS4-2021-2024-07-1032', '', '', '', 2, '2023-10-19 22:00:00', NULL, 1, '2023-10-20', '2026-10-20', 'Advanced  Animal Health Service', 'IV', 'Y/ALEM ANIMAL HEALTH', 'C.O 3591570'),
(10, 'SHALEKA TESHOME LUTE', 'ARG-AAHS4-2021-2024-07-1404', '', '', '', 2, '2021-10-19 22:00:00', NULL, 0, '2021-10-20', '2024-10-20', 'Advanced  Animal Health Service', 'IV', 'Y/ALEM ANIMAL HEALTH', 'C.O 3591572'),
(11, 'DEGIFE DEBEKO DANOLE', 'ARG-AAHS4-2021-2024-07-1230', '', '', '', 2, '2025-10-19 22:00:00', NULL, 1, '2025-10-20', '2028-10-20', 'Advanced  Animal Health Service', 'IV', 'Y/ALEM ANIMAL HEALTH', 'C.O 3591568'),
(12, 'HELEN TESFAYE MOTOSSA', 'ARG-AAHS4-2021-2024-07-1013', '', '', '', 2, '2024-10-19 22:00:00', NULL, 1, '2024-10-20', '2027-10-20', 'Advanced  Animal Health Service', 'IV', 'Y/ALEM ANIMAL HEALTH', 'C.O 3591569'),
(13, 'DINKINESH TADESE  OTE', 'ARG-AAHS4-2021-2024-07-1083', '', '', '', 2, '2023-10-19 22:00:00', '2026-03-02 11:42:07', 0, '2023-10-20', '2026-03-25', 'Advanced  Animal Health Service', 'IV', 'Y/ALEM ANIMAL HEALTH', 'C.O 3591571'),
(14, 'SHEBELA SHMMO SHABU', 'ARG-AAHS4-2021-2024-07-1214', '', '', '', 2, '2021-10-19 22:00:00', '2026-03-02 11:41:11', 0, '2024-10-20', '2027-10-19', 'Advanced  Animal Health Service', 'IV', 'Y/ALEM ANIMAL HEALTH', 'C.O 3591572'),
(15, 'DEGIFE DEBEKO DANOLE', 'ARG-AAHS4-2021-2024-07-1234', '', '', '', 2, '2025-10-19 22:00:00', NULL, 1, '2025-10-20', '2028-10-20', 'Advanced  Animal Health Service', 'IV', 'Y/ALEM ANIMAL HEALTH', 'C.O 3591568'),
(16, 'HELEN TESFAYE MOTOSSA', 'ARG-AAHS4-2021-2024-07-1567', '', '', '', 2, '2024-10-19 22:00:00', NULL, 1, '2024-10-20', '2027-10-20', 'Advanced  Animal Health Service', 'IV', 'Y/ALEM ANIMAL HEALTH', 'C.O 3591569'),
(17, 'AYALEW ADALA TOSHE', 'ARG-AAHS4-2021-2024-07-1342', '', '', '', 2, '2023-10-19 22:00:00', NULL, 1, '2023-10-20', '2026-10-20', 'Advanced  Animal Health Service', 'IV', 'Y/ALEM ANIMAL HEALTH', 'C.O 3591570'),
(18, 'DINKINESH TADESE  OTE', 'ARG-AAHS4-2021-2024-07-1453', '', '', '', 2, '2023-10-19 22:00:00', NULL, 0, '2023-10-20', '2024-10-20', 'Advanced  Animal Health Service', 'IV', 'Y/ALEM ANIMAL HEALTH', 'C.O 3591571'),
(19, 'SHALEKA TESHOME LUTE', 'ARG-AAHS4-2021-2024-07-1987', '', '', '', 2, '2021-10-19 22:00:00', NULL, 0, '2021-10-20', '2024-10-20', 'Advanced  Animal Health Service', 'IV', 'Y/ALEM ANIMAL HEALTH', 'C.O 3591572'),
(20, 'Dawit for Test', 'SN-OCAA-CZUA-2025-2029-00-0000', '', '', '', NULL, '2026-03-02 11:46:38', '2026-03-02 14:53:49', 0, '2026-03-01', '2029-03-20', 'Student of CZU', 'II', 'CZU', 'CZU001'),
(21, 'Dawit for Test1', 'ARG-AAHS4-2027-2029-00-000', '', '', '', NULL, '2026-03-02 11:48:38', '2026-03-05 08:59:03', 0, '2026-03-04', '2027-03-30', 'Student of CZU', 'IV', 'CZU', 'CZU002'),
(22, 'Dawit for Test3', 'SN-OCAA-CZUA-2025-2029-00-0000', '', '', '', NULL, '2026-03-05 09:01:59', NULL, 0, '2025-03-05', '2027-03-29', 'Student of CZU', 'III', 'CZU Main Campus', 'CZU010');

-- --------------------------------------------------------

--
-- Table structure for table `tblsubjectcombination`
--

CREATE TABLE `tblsubjectcombination` (
  `id` int(100) NOT NULL,
  `ClassId` int(100) NOT NULL,
  `SubjectId` int(100) NOT NULL,
  `status` int(1) DEFAULT NULL,
  `CreationDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `Updationdate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblsubjects`
--

CREATE TABLE `tblsubjects` (
  `id` int(100) NOT NULL,
  `SubjectName` varchar(100) NOT NULL,
  `SubjectCode` varchar(100) NOT NULL,
  `Creationdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structure for view `students_excel`
--
DROP TABLE IF EXISTS `students_excel`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `students_excel`  AS SELECT `tblstudents`.`StudentId` AS `student_id`, `tblstudents`.`RollId` AS `certificate_number`, `tblstudents`.`StudentName` AS `name_of_candidate`, `tblstudents`.`Occupation` AS `occupation`, `tblstudents`.`Level` AS `level`, `tblstudents`.`activation_date` AS `issued_on`, `tblstudents`.`expiry_date` AS `valid_until`, `tblstudents`.`Venue` AS `assessment_center`, `tblstudents`.`ControlNo` AS `control_no`, `tblstudents`.`Status` AS `status` FROM `tblstudents` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_admin_role_id` (`role_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `tblclasses`
--
ALTER TABLE `tblclasses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblresult`
--
ALTER TABLE `tblresult`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblstudents`
--
ALTER TABLE `tblstudents`
  ADD PRIMARY KEY (`StudentId`);

--
-- Indexes for table `tblsubjectcombination`
--
ALTER TABLE `tblsubjectcombination`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblsubjects`
--
ALTER TABLE `tblsubjects`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblclasses`
--
ALTER TABLE `tblclasses`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblresult`
--
ALTER TABLE `tblresult`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblstudents`
--
ALTER TABLE `tblstudents`
  MODIFY `StudentId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tblsubjectcombination`
--
ALTER TABLE `tblsubjectcombination`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblsubjects`
--
ALTER TABLE `tblsubjects`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin`
--
ALTER TABLE `admin`
  ADD CONSTRAINT `fk_admin_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`),
  ADD CONSTRAINT `fk_admin_role_id` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
