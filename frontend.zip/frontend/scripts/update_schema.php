<?php
/*
 * Project: COC Verification system for sidama region
 * Purpose: Master's Degree Thesis 
 * * Description: This software was developed to solve a real-world problem as part of 
 * the graduation requirements for the Master's Program.
 * * Author: Dawit Birru Hurisso
 * Institution: Czech University of Life Sciences Prague (CZU)
 * Graduate Year: 2026
 */
require_once __DIR__ . '/../includes/db.php';

$dbh = getPDO();

$wanted = [
    'Occupation' => "VARCHAR(255) DEFAULT NULL",
    'Level' => "VARCHAR(100) DEFAULT NULL",
    'activation_date' => "DATETIME DEFAULT NULL",
    'expiry_date' => "DATETIME DEFAULT NULL",
    'Venue' => "VARCHAR(255) DEFAULT NULL",
    'ControlNo' => "VARCHAR(100) DEFAULT NULL",
    // optional: StudentEmail, Gender, DOB already exist in schema
];

$existing = [];
foreach ($dbh->query("SHOW COLUMNS FROM tblstudents") as $col) {
    $existing[$col['Field']] = $col;
}

$added = [];
foreach ($wanted as $col => $def) {
    if (!isset($existing[$col])) {
        $sql = "ALTER TABLE tblstudents ADD COLUMN `$col` $def";
        echo "Adding column $col...\n";
        try {
            $dbh->exec($sql);
            $added[] = $col;
            echo "  OK\n";
        } catch (Exception $e) {
            echo "  Failed: " . $e->getMessage() . "\n";
        }
    } else {
        echo "Column $col already exists, skipping.\n";
    }
}

if (!empty($added)) {
    echo "Added columns: " . implode(', ', $added) . "\n";
} else {
    echo "No columns added.\n";
}

// Make ClassId nullable to avoid 0 default if desired
try {
    $dbh->exec("ALTER TABLE tblstudents MODIFY ClassId INT(100) DEFAULT NULL");
    echo "ClassId modified to allow NULL.\n";
} catch (Exception $e) {
    echo "Modify ClassId failed or already nullable: " . $e->getMessage() . "\n";
}

echo "Done.\n";
