<?php
/*
 * Project: COC Verification system for sidama region
 * Purpose: Master's Degree Thesis 
 * * Description: This software was developed to solve a real-world problem as part of 
 * the graduation requirements for the Master's Program.
 * * Author: Dawit Birru Hurisso
 * Institution: Czech University of Life Sciences Prague (CZU)
 * Graduate Year: 2026
 */
require_once __DIR__ . '/../includes/db.php';

try {
    $dbh = getPDO();
    $cnt = $dbh->query("SELECT COUNT(*) AS cnt FROM tblstudents")->fetchColumn();
    echo "tblstudents count: " . $cnt . PHP_EOL . PHP_EOL;

    $stmt = $dbh->query("SELECT StudentId, RollId, StudentName, ClassId, StudentEmail, RegDate FROM tblstudents ORDER BY StudentId DESC LIMIT 10");
    echo "Last students:\n";
    foreach ($stmt as $r) {
        echo json_encode($r) . PHP_EOL;
    }

    echo PHP_EOL . "Classes:\n";
    $stmt = $dbh->query("SELECT id, ClassName, ClassNameNumeric, Section FROM tblclasses LIMIT 50");
    foreach ($stmt as $r) {
        echo json_encode($r) . PHP_EOL;
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . PHP_EOL;
}
