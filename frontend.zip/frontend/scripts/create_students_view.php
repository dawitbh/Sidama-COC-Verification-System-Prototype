<?php
/*
 * Project: COC Verification system for sidama region
 * Purpose: Master's Degree Thesis 
 * * Description: This software was developed to solve a real-world problem as part of 
 * the graduation requirements for the Master's Program.
 * * Author: Dawit Birru Hurisso
 * Institution: Czech University of Life Sciences Prague (CZU)
 * Graduate Year: 2026
 */
require_once __DIR__ . '/../includes/db.php';

try {
    $dbh = getPDO();

    $sql = <<<'SQL'
CREATE OR REPLACE VIEW students_excel AS
SELECT
  StudentId      AS student_id,
  RollId         AS certificate_number,
  StudentName    AS name_of_candidate,
  Occupation     AS occupation,
  `Level`        AS level,
  activation_date AS issued_on,
  expiry_date     AS valid_until,
  Venue          AS assessment_center,
  ControlNo      AS control_no,
  Status         AS status
FROM tblstudents;
SQL;

    $dbh->exec($sql);
    echo "View 'students_excel' created or replaced successfully.\n";
} catch (PDOException $e) {
    echo "Error creating view: " . $e->getMessage() . "\n";
    exit(1);
}

