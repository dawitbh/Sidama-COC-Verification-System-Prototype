-- Migration: add certificate workflow columns and audit_log table

ALTER TABLE `tblstudents`
  ADD COLUMN `status` ENUM('pending','active','revoked') NOT NULL DEFAULT 'pending',
  ADD COLUMN `approved_by` INT NULL DEFAULT NULL,
  ADD COLUMN `approved_at` DATETIME NULL DEFAULT NULL,
  ADD COLUMN `revoked_by` INT NULL DEFAULT NULL,
  ADD COLUMN `revoked_at` DATETIME NULL DEFAULT NULL,
  ADD COLUMN `revoke_reason` VARCHAR(255) NULL DEFAULT NULL;

CREATE TABLE IF NOT EXISTS `audit_log` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NULL,
  `action` VARCHAR(50) NOT NULL,
  `entity` VARCHAR(50) NULL,
  `entity_id` INT NULL,
  `details` TEXT NULL,
  `ip_address` VARCHAR(45) NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
