<?php
/*
 * Project: COC Verification system for sidama region
 * Purpose: Master's Degree Thesis 
 * * Description: This software was developed to solve a real-world problem as part of 
 * the graduation requirements for the Master's Program.
 * * Author: Dawit Birru Hurisso
 * Institution: Czech University of Life Sciences Prague (CZU)
 * Graduate Year: 2026
 */
// Language switcher partial — simplified: icon-only control (no flag images)
// Flags are intentionally not shown here so they appear only on the login branding panel.
?>
<div class="language-switcher d-flex align-items-center" role="navigation" aria-label="Language switcher">
  <button type="button" class="lang-btn btn btn-sm" aria-haspopup="true" aria-expanded="false" title="Language">
    <i class="bi bi-translate" aria-hidden="true"></i>
    <span class="visually-hidden">Change language</span>
  </button>
</div>

<script>
// Keep a minimal language interaction placeholder (keeps localStorage shape if other pages rely on it)
(function(){
  var btn = document.querySelector('.language-switcher .lang-btn');
  if (!btn) return;
  btn.addEventListener('click', function(){
    // simple toggle between 'en' and 'am' for convenience
    var current = localStorage.getItem('cvst_lang') || 'en';
    var next = current === 'en' ? 'am' : 'en';
    localStorage.setItem('cvst_lang', next);
    btn.setAttribute('aria-expanded', next !== 'en');
    // small visual cue
    btn.classList.add('pulse'); setTimeout(()=>btn.classList.remove('pulse'), 480);
  });
})();
</script>
