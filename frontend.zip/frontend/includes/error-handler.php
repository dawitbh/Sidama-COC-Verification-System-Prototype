<?php
/*
 * Project: COC Verification system for sidama region
 * Purpose: Master's Degree Thesis 
 * * Description: This software was developed to solve a real-world problem as part of 
 * the graduation requirements for the Master's Program.
 * * Author: Dawit Birru Hurisso
 * Institution: Czech University of Life Sciences Prague (CZU)
 * Graduate Year: 2026
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/db.php';

function logError(string $message, array $context = []): void {
    $logDir = __DIR__ . '/../logs';
    if (!is_dir($logDir)) {
        @mkdir($logDir, 0750, true);
    }
    $logFile = $logDir . '/app.log';
    $now = (new DateTime())->format('Y-m-d H:i:s');
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    if (strpos($ip, ',') !== false) { $ip = trim(explode(',', $ip)[0]); }
    $userId = $_SESSION['user']['id'] ?? 'public';
    $payload = [
        'time' => $now,
        'ip' => $ip,
        'user_id' => $userId,
        'message' => $message,
        'context' => $context,
    ];
    $line = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . PHP_EOL;
    @file_put_contents($logFile, $line, FILE_APPEND | LOCK_EX);
}

function renderError(int $code, ?string $title = null, ?string $message = null, ?string $actionLink = null, ?string $actionText = null, ?string $hint = null): void {
    http_response_code($code);
    $file = __DIR__ . "/../errors/{$code}.php";
    if (!file_exists($file)) {
        // fallback simple output
        echo '<!doctype html><meta charset="utf-8"><title>' . htmlspecialchars($title ?? 'Error') . '</title><p>' . htmlspecialchars($message ?? 'An error occurred.') . '</p>';
        exit;
    }
    // expose variables to the included template
    $title = $title ?? null;
    $message = $message ?? null;
    $actionLink = $actionLink ?? null;
    $actionText = $actionText ?? null;
    $hint = $hint ?? null;
    include $file;
    exit;
}

// Global exception handler: log details (including stack) and show friendly 500 page
set_exception_handler(function (Throwable $ex) {
    try {
        $context = [
            'exception' => get_class($ex),
            'message' => $ex->getMessage(),
            'file' => $ex->getFile(),
            'line' => $ex->getLine(),
            'trace' => $ex->getTraceAsString(),
        ];
        logError('Uncaught exception: ' . $ex->getMessage(), $context);
    } catch (Throwable $t) {
        // best-effort logging
        @error_log('Failed to log exception: ' . $t->getMessage());
    }

    // Do not reveal internal details to users
    renderError(500, '500 — Server Error', 'Something went wrong. Please try again.', 'dashboard.php', 'Back to Dashboard');
});

// Error handler: convert warnings/notices to logs; suppress exposing details to users
set_error_handler(function (int $errno, string $errstr, string $errfile, int $errline) {
    // Map error level name
    $levels = [
        E_ERROR => 'E_ERROR', E_WARNING => 'E_WARNING', E_PARSE => 'E_PARSE', E_NOTICE => 'E_NOTICE',
        E_CORE_ERROR => 'E_CORE_ERROR', E_CORE_WARNING => 'E_CORE_WARNING', E_COMPILE_ERROR => 'E_COMPILE_ERROR', E_COMPILE_WARNING => 'E_COMPILE_WARNING',
        E_USER_ERROR => 'E_USER_ERROR', E_USER_WARNING => 'E_USER_WARNING', E_USER_NOTICE => 'E_USER_NOTICE',
        E_STRICT => 'E_STRICT', E_RECOVERABLE_ERROR => 'E_RECOVERABLE_ERROR', E_DEPRECATED => 'E_DEPRECATED', E_USER_DEPRECATED => 'E_USER_DEPRECATED'
    ];
    $level = $levels[$errno] ?? 'E_UNKNOWN';
    $context = [
        'level' => $level,
        'message' => $errstr,
        'file' => $errfile,
        'line' => $errline,
        'backtrace' => debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 5),
    ];
    logError('PHP error: ' . $errstr, $context);

    // Do not execute PHP internal error handler
    return true;
});

// Shutdown handler: detect fatal errors and render 500 page
register_shutdown_function(function () {
    $err = error_get_last();
    if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true)) {
        try {
            $context = [
                'type' => $err['type'],
                'message' => $err['message'],
                'file' => $err['file'],
                'line' => $err['line'],
            ];
            logError('Fatal error on shutdown: ' . ($err['message'] ?? 'unknown'), $context);
        } catch (Throwable $t) {
            @error_log('Failed to log shutdown error: ' . $t->getMessage());
        }

        // If headers not sent, render friendly 500 page
        if (!headers_sent()) {
            renderError(500, '500 — Server Error', 'Something went wrong. Please try again.', 'dashboard.php', 'Back to Dashboard');
        }
    }
});
