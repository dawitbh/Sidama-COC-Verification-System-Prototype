<?php
/*
 * Project: COC Verification system for sidama region
 * Purpose: Master's Degree Thesis 
 * * Description: This software was developed to solve a real-world problem as part of 
 * the graduation requirements for the Master's Program.
 * * Author: Dawit Birru Hurisso
 * Institution: Czech University of Life Sciences Prague (CZU)
 * Graduate Year: 2026
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Permission constants
define('PERM_CERT_VIEW', 'PERM_CERT_VIEW');
define('PERM_CERT_CREATE', 'PERM_CERT_CREATE');
define('PERM_CERT_EDIT', 'PERM_CERT_EDIT');
define('PERM_CERT_DELETE', 'PERM_CERT_DELETE');
define('PERM_CERT_IMPORT', 'PERM_CERT_IMPORT');
define('PERM_USER_MANAGE', 'PERM_USER_MANAGE');
define('PERM_CERT_APPROVE', 'PERM_CERT_APPROVE');
define('PERM_CERT_REVOKE', 'PERM_CERT_REVOKE');
// Use stable dot-names for permission identifiers
define('PERM_PROFILE_SETTINGS', 'profile.settings');

/**
 * Return the permission list for a role name.
 * @param string|null $role
 * @return array
 */
function rolePermissions(?string $role): array {
    if ($role === null) return [];
    switch ($role) {
        case 'viewer':
            return [PERM_CERT_VIEW];
        case 'data_entry':
            return [PERM_CERT_VIEW, PERM_CERT_CREATE, PERM_CERT_EDIT, PERM_CERT_IMPORT];
        case 'admin':
            return [PERM_CERT_VIEW, PERM_CERT_CREATE, PERM_CERT_EDIT, PERM_CERT_DELETE, PERM_CERT_IMPORT, PERM_PROFILE_SETTINGS];
        case 'super_admin':
            return ['*'];
        default:
            return [];
    }
}

/**
 * Check whether current session role can perform the given permission.
 * Reads role from $_SESSION['role_name'] (set at login).
 */
function can(string $permission): bool {
    $role = $_SESSION['role_name'] ?? ($_SESSION['user']['role_name'] ?? null);
    if ($role === null) return false;
    $perms = rolePermissions($role);
    if (in_array('*', $perms, true)) return true;
    return in_array($permission, $perms, true);
}

/**
 * Require a permission and render a 403 error page when denied.
 * @param string $permission
 */
function requirePermissionCentral(string $permission): void {
    if (!can($permission)) {
        // Prefer centralized error renderer if available
        if (file_exists(__DIR__ . '/error-handler.php')) {
            require_once __DIR__ . '/error-handler.php';
            logError('Permission denied', ['permission' => $permission, 'role' => $_SESSION['role_name'] ?? null, 'script' => $_SERVER['SCRIPT_NAME'] ?? '']);
            renderError(403, '403 — Forbidden', 'You do not have permission to access this page.', 'dashboard.php', 'Back to Dashboard');
        }
        http_response_code(403);
        echo 'Forbidden';
        exit;
    }
}

// Export a compat wrapper name `requirePermission` used across the codebase
if (!function_exists('requirePermission')) {
    function requirePermission($perm) {
        // allow passing array (any)
        if (is_array($perm)) {
            foreach ($perm as $p) {
                if (can($p)) return;
            }
            requirePermissionCentral(implode('|', $perm));
        } else {
            requirePermissionCentral($perm);
        }
    }
}
