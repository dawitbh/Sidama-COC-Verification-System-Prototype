
<!--
/*
 * Project: COC Verification system for sidama region
 * Purpose: Master's Degree Thesis 
 * * Description: This software was developed to solve a real-world problem as part of 
 * the graduation requirements for the Master's Program.
 * * Author: Dawit Birru Hurisso
 * Institution: Czech University of Life Sciences Prague (CZU)
 * Graduate Year: 2026
 */
-->
</div>
<footer class="site-footer">
	<!-- Unified responsive footer bar -->
	<style>
	/* Unified footer bar: single text + optional logo on desktop */
	.site-footer .footer-bar{background:linear-gradient(90deg,#0b66e3,#67b3ff);color:#fff;padding:10px 18px;border-radius:10px;display:flex;align-items:center;justify-content:center}
	.site-footer .footer-bar .bar-inner{width:100%;max-width:1100px;display:flex;align-items:center;gap:12px}
	.site-footer .footer-bar .copy{width:100%;text-align:center;font-size:0.92rem}
	@media(min-width:768px){
		.site-footer .footer-bar{justify-content:center}
		.site-footer .footer-bar .logo-placeholder{display:inline-block}
		.site-footer .footer-bar .copy{text-align:left}
	}
	</style>
	<div class="footer-bar">
		<div class="bar-inner">
			<div class="copy">&copy; <?= date('Y') ?> Sidama CVS — Developed by Dawit Birru Hurisso</div>
		</div>
	</div>

	<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
	<!-- html2pdf for client-side PDF exports (small, CDN) -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>
	<script src="assets/js/flags-wave.js"></script>
</footer>
</body>
</html>
