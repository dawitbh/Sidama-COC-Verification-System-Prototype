<?php
/*
 * Project: COC Verification system for sidama region
 * Purpose: Master's Degree Thesis 
 * * Description: This software was developed to solve a real-world problem as part of 
 * the graduation requirements for the Master's Program.
 * * Author: Dawit Birru Hurisso
 * Institution: Czech University of Life Sciences Prague (CZU)
 * Graduate Year: 2026
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'cookie_httponly' => true,
        'cookie_secure'   => isset($_SERVER['HTTPS']),
        'cookie_samesite' => 'Lax',
    ]);
}

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/permissions.php';

function currentUser() {
    return $_SESSION['user'] ?? null;
}

// hasPermission delegates to centralized permissions (session-based)
function hasPermission(string $perm): bool {
    return can($perm);
}

function render403(): void {
    require_once __DIR__ . '/error-handler.php';
    logError('403 forbidden rendered', ['script' => $_SERVER['SCRIPT_NAME'] ?? '']);
    renderError(403, '403 — Forbidden', 'You do not have permission to access this page.', '/index.php', 'Sign in');
}

function requireLogin(): void {
    if (!isset($_SESSION['user'])) {
        // set a warning flash and redirect to login
        setFlash('warning', 'Please sign in to continue.');
        header('Location: index.php');
        exit;
    }
}

/**
 * Return the current logged-in user's role name.
 * Caches the name in `$_SESSION['user']['role_name']` to avoid repeated queries.
 * If the role cannot be resolved, access is denied.
 *
 * @return string|null role name or null if not logged in
 */
function getUserRoleName(): ?string {
    if (!isset($_SESSION['user'])) {
        return null;
    }

    // prefer top-level cached role_name (set at login)
    if (!empty($_SESSION['role_name'])) {
        // mirror into user array for compatibility
        $_SESSION['user']['role_name'] = $_SESSION['role_name'];
        return $_SESSION['role_name'];
    }

    // Return cached value when present in user array
    if (!empty($_SESSION['user']['role_name'])) {
        return $_SESSION['user']['role_name'];
    }

    // Attempt to resolve from role_id
    $roleId = $_SESSION['user']['role_id'] ?? null;
    if (empty($roleId)) {
        render403();
    }

    try {
        $dbh = getPDO();
        $stmt = $dbh->prepare('SELECT name FROM roles WHERE id = :id LIMIT 1');
        $stmt->execute([':id' => $roleId]);
        $row = $stmt->fetch();
    } catch (Exception $e) {
        // On DB error, deny access rather than exposing internals
        render403();
    }

    if (!$row || empty($row['name'])) {
        render403();
    }

    // Cache and return
    $_SESSION['user']['role_name'] = $row['name'];
    return $row['name'];
}

/**
 * Require that the current logged-in user has one of the allowed roles.
 * Shows a 403 page and exits when not allowed.
 *
 * @param array $allowedRoles list of role name strings
 */
function requireRole(array $allowedRoles): void {
    // ensure user is logged in (sets flash+redirect if not)
    requireLogin();
    $role = getUserRoleName();
    if ($role === null || !in_array($role, $allowedRoles, true)) {
        // consistent 403 rendering for role failures
        require_once __DIR__ . '/error-handler.php';
        logError('requireRole denied', ['allowed' => $allowedRoles, 'role' => $role, 'script' => $_SERVER['SCRIPT_NAME'] ?? '']);
        renderError(403,
            '403 — Forbidden',
            'You do not have permission to access this page.',
            'dashboard.php',
            'Back to Dashboard',
            'Your role is not allowed to access this feature.'
        );
    }
}

function hasRole(string $role): bool {
    $name = getUserRoleName();
    if ($name === null) return false;
    return hash_equals($name, $role);
}

function hasAnyRole(array $roles): bool {
    $name = getUserRoleName();
    if ($name === null) return false;
    return in_array($name, $roles, true);
}
