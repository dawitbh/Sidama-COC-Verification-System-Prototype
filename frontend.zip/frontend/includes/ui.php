<?php
/*
 * Project: COC Verification system for sidama region
 * Purpose: Master's Degree Thesis 
 * * Description: This software was developed to solve a real-world problem as part of 
 * the graduation requirements for the Master's Program.
 * * Author: Dawit Birru Hurisso
 * Institution: Czech University of Life Sciences Prague (CZU)
 * Graduate Year: 2026
 */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/permissions.php';

/**
 * Echo action HTML only when the current role has the given permission.
 * @param string $permission
 * @param string $html
 */
function ui_action_button(string $permission, string $html): void {
    if (can($permission)) {
        echo $html;
    }
}
