<?php
/*
 * Project: COC Verification system for sidama region
 * Purpose: Master's Degree Thesis 
 * * Description: This software was developed to solve a real-world problem as part of 
 * the graduation requirements for the Master's Program.
 * * Author: Dawit Birru Hurisso
 * Institution: Czech University of Life Sciences Prague (CZU)
 * Graduate Year: 2026
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


$user = $_SESSION['user'] ?? null;
// Load helpers and UI early so header can safely call `can()` / `ui_action_button()`
require_once __DIR__ . '/helpers.php';
if (file_exists(__DIR__ . '/ui.php')) require_once __DIR__ . '/ui.php';
// Include confirmation modal (provides `confirmAction()` and auto-wiring)
if (file_exists(__DIR__ . '/confirm-modal.php')) require_once __DIR__ . '/confirm-modal.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sidaama Region COC certificate verification system</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link href="css/app.css" rel="stylesheet">
    <style>
    /* Subtle decorative flags behind the page content */
    body{position:relative}
    body::before, body::after{content:'';position:fixed;pointer-events:none;opacity:.06;z-index:0;background-repeat:no-repeat;background-position:center;background-size:contain}
    body::before{background-image:url('assets/img/sidama.svg');right:6%;bottom:8%;width:360px;height:220px;transform:rotate(-8deg)}
    body::after{background-image:url('assets/img/ethiopia.svg');left:4%;top:6%;width:260px;height:160px;transform:rotate(2deg)}
    @media(max-width:768px){body::before,body::after{display:none}}
    
    /* Global navbar layout helpers: keep navbar fixed and ensure page content
       isn't hidden behind it. Uses JS below to compute exact height. */
    .app-navbar { position: fixed; top: 0; left: 0; right: 0; width: 100%; z-index: 1050; }
    body { margin-top: 0; }
    </style>
    <script>
    // Compute navbar height and apply padding to body so pages don't need per-page tweaks.
    document.addEventListener('DOMContentLoaded', function(){
      function updateNavSpacing(){
        var nav = document.querySelector('.app-navbar') || document.querySelector('.navbar');
        var h = nav ? Math.ceil(nav.getBoundingClientRect().height) : 72;
        document.documentElement.style.setProperty('--navbar-height', h + 'px');
        document.body.style.paddingTop = h + 'px';
      }
      updateNavSpacing();
      window.addEventListener('resize', updateNavSpacing);
    });
    </script>
  <?php if (!empty($auth_css)): ?>
  <link href="css/auth.css" rel="stylesheet">
  <?php endif; ?>
</head>
<body class="bg-light<?= !empty($auth_page) ? ' auth-page' : '' ?>">
<nav class="navbar navbar-expand-lg app-navbar shadow-sm fixed-top">
  <div class="container-fluid">
    <div class="d-flex align-items-center w-100 app-bar-content">
      <a class="navbar-brand d-flex align-items-center me-3" href="dashboard.php">
      <?php
      // prefer an uploaded logo in assets/, fall back to inline SVG placeholder
      $logoPathSvg = __DIR__ . '/../assets/logo.svg';
      $logoPathPng = __DIR__ . '/../assets/logo.png';
      $logoUrl = null;
      if (file_exists($logoPathSvg)) {
          $logoUrl = 'assets/logo.svg';
      } elseif (file_exists($logoPathPng)) {
          $logoUrl = 'assets/logo.png';
      }
      if ($logoUrl): ?>
        <img src="<?= htmlspecialchars($logoUrl) ?>" alt="Logo" class="site-logo me-2" />
      <?php else: ?>
        <span class="site-logo-placeholder rounded-circle d-inline-flex align-items-center justify-content-center me-2" aria-hidden="true">
          <svg width="40" height="40" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" role="img">
            <rect rx="8" width="48" height="48" fill="#0B5ED7" />
            <path d="M12 28c4-6 10-10 18-10" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
            <circle cx="34" cy="14" r="4" fill="#fff" />
          </svg>
        </span>
      <?php endif; ?>
      <div class="d-flex flex-column">
        <span class="brand-title">Sidaama Region COC</span>
        <small class="text-white-50">certificate verification system</small>
      </div>
      </a>

      <div class="flex-fill d-flex justify-content-start px-3">
        <!-- Intentionally left empty to create breathing space; search removed as requested -->
      </div>

      <!-- Header flags (always visible for branding) -->
      <div class="header-flags d-flex align-items-center gap-2 me-2">
        <div class="flag-wrap" data-label="Ethiopia" tabindex="0" role="img" aria-label="Ethiopia">
          <img class="flag-img" src="assets/img/ethiopia.svg" alt="Ethiopia Flag">
        </div>
        <div class="flag-wrap" data-label="Sidama" tabindex="0" role="img" aria-label="Sidama">
          <img class="flag-img" src="assets/img/sidama.svg" alt="Sidama Flag">
        </div>
      </div>

      <?php if (empty($hide_login)): ?>
      <div class="d-flex align-items-center ms-auto gap-2">
        <!-- Language switcher removed per request -->

        <!-- External SVG filters will be injected here by JS (keeps header clean) -->
        <div id="flag-filters-root" style="position:absolute;width:0;height:0;overflow:hidden;pointer-events:none;" aria-hidden="true"></div>

        <?php if ($user): ?>
          <div class="user-area d-flex align-items-center gap-3">
            <div class="dropdown">
              <button class="btn user-btn d-flex align-items-center" id="userMenu" data-bs-toggle="dropdown" aria-expanded="false">
                <div class="user-info d-none d-md-flex flex-column text-start me-2">
                  <span class="user-name"><?= htmlspecialchars($user['username']) ?></span>
                  <small class="user-role"><?= htmlspecialchars(str_replace('_',' ', $user['role_name'] ?? 'User')) ?></small>
                </div>
                <div class="user-avatar" aria-hidden="true"><?= htmlspecialchars(strtoupper($user['username'][0] ?? 'U')) ?></div>
              </button>
              <ul class="dropdown-menu dropdown-menu-end shadow-sm" aria-labelledby="userMenu">
                <li class="px-3 py-2">
                  <div class="d-flex align-items-center gap-3">
                    <div class="icon-square avatar-square me-2" aria-hidden="true"><?= htmlspecialchars(strtoupper($user['username'][0] ?? 'U')) ?></div>
                    <div>
                      <strong><?= htmlspecialchars($user['username']) ?></strong>
                      <div class="text-muted small">Role: <?= htmlspecialchars(str_replace('_',' ', $user['role_name'] ?? 'User')) ?></div>
                    </div>
                  </div>
                </li>
                <li><hr class="dropdown-divider"></li>
                <?php if (function_exists('can') && can(PERM_USER_MANAGE)): ?>
                  <li class="px-3 py-2">
                    <a class="btn w-100 btn-admin-panel" href="manage-users.php"><i class="bi bi-shield-lock me-2"></i> Open Admin Panel</a>
                  </li>
                  <li><hr class="dropdown-divider"></li>
                <?php endif; ?>
                <?php
                // Show Profile & Settings only if user has the permission.
                if (function_exists('ui_action_button')) {
                  ui_action_button(PERM_PROFILE_SETTINGS, '<li><a class="dropdown-item" href="profile.php">Profile &amp; Settings</a></li>');
                } else {
                  if (function_exists('can') && can(PERM_PROFILE_SETTINGS)) {
                    echo '<li><a class="dropdown-item" href="profile.php">Profile &amp; Settings</a></li>';
                  }
                }
                ?>
                <li>
                  <form action="logout.php" method="post" class="m-0">
                    <button type="submit" class="dropdown-item">Logout</button>
                  </form>
                </li>
              </ul>
            </div>
          </div>
        <?php else: ?>
          <?php if (empty($hide_login)): ?>
            <a class="btn btn-outline-light btn-sm" href="index.php">Login</a>
          <?php endif; ?>
        <?php endif; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>
  </nav>
  <div class="container-fluid py-3">
