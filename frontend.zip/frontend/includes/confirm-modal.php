<?php

/*
 * Project: COC Verification system for sidama region
 * Purpose: Master's Degree Thesis 
 * * Description: This software was developed to solve a real-world problem as part of 
 * the graduation requirements for the Master's Program.
 * * Author: Dawit Birru Hurisso
 * Institution: Czech University of Life Sciences Prague (CZU)
 * Graduate Year: 2026
 */

// Reusable confirmation modal component (HTML + CSS + JS).
// Include this file in the header so the modal and `confirmAction()` are available globally.
?>

<!-- Confirmation modal (initially hidden) -->
<div id="cvst-confirm-overlay" class="cvst-confirm-overlay" aria-hidden="true">
  <div class="cvst-confirm" role="dialog" aria-modal="true" aria-labelledby="cvst-confirm-title">
    <button type="button" class="cvst-confirm-close" aria-label="Close">&times;</button>
    <div class="cvst-confirm-body">
      <h3 id="cvst-confirm-title" class="cvst-confirm-title">Confirm</h3>
      <p class="cvst-confirm-message">Are you sure?</p>
      <div class="cvst-confirm-actions">
        <button type="button" class="cvst-confirm-btn cvst-confirm-cancel">Cancel</button>
        <button type="button" class="cvst-confirm-btn cvst-confirm-confirm">Confirm</button>
      </div>
    </div>
  </div>
</div>

<style>
/* Modal overlay */
.cvst-confirm-overlay{position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(2,6,23,0.4);z-index:1050}
.cvst-confirm-overlay.open{display:flex}
/* Card */
.cvst-confirm{background:#fff;border-radius:16px;box-shadow:0 20px 40px rgba(2,6,23,0.12);max-width:520px;width:92%;transform:translateY(6px) scale(.98);opacity:0;transition:opacity .18s ease,transform .18s ease;padding:0.5rem}
.cvst-confirm-overlay.open .cvst-confirm{transform:translateY(0) scale(1);opacity:1}
.cvst-confirm-body{padding:20px}
.cvst-confirm-title{margin:0 0 8px;font-size:18px}
.cvst-confirm-message{margin:0 0 16px;color:#505763}
.cvst-confirm-close{position:absolute;right:14px;top:10px;border:0;background:transparent;font-size:22px;line-height:1;color:#8892a6;cursor:pointer}

/* Actions */
.cvst-confirm-actions{display:flex;gap:10px;justify-content:flex-end}
.cvst-confirm-btn{padding:8px 14px;border-radius:10px;border:0;cursor:pointer;font-weight:600}
.cvst-confirm-cancel{background:#f3f4f6;color:#111827}
.cvst-confirm-confirm{background:#0b63c6;color:#fff}

/* Color variants */
.cvst-confirm-confirm.danger{background:#d9534f}
.cvst-confirm-confirm.warning{background:#f59e0b}
.cvst-confirm-confirm.primary{background:#0b63c6}

@media (max-width:480px){.cvst-confirm{width:94%;padding:0.4rem}.cvst-confirm-title{font-size:16px}}
</style>

<script>
(function () {
  'use strict';

  var overlay = document.getElementById('cvst-confirm-overlay');
  var titleEl = overlay ? overlay.querySelector('.cvst-confirm-title') : null;
  var msgEl = overlay ? overlay.querySelector('.cvst-confirm-message') : null;
  var btnConfirm = overlay ? overlay.querySelector('.cvst-confirm-confirm') : null;
  var btnCancel = overlay ? overlay.querySelector('.cvst-confirm-cancel') : null;
  var btnClose = overlay ? overlay.querySelector('.cvst-confirm-close') : null;

  if (!overlay) return;

  function openOverlay() {
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
    overlay.setAttribute('aria-hidden', 'false');
  }
  function closeOverlay() {
    overlay.classList.remove('open');
    document.body.style.overflow = '';
    overlay.setAttribute('aria-hidden', 'true');
  }

  // Default options
  var defaults = {
    title: '',
    message: '',
    confirmText: 'Confirm',
    confirmClass: 'danger', // 'danger' | 'warning' | 'primary'
    onConfirm: function () {}
  };

  // Expose global confirmAction
  window.confirmAction = function (opts) {
    var options = Object.assign({}, defaults, opts || {});

    // set content
    if (titleEl) titleEl.textContent = options.title || '';
    if (msgEl) msgEl.textContent = options.message || '';
    if (btnConfirm) {
      btnConfirm.textContent = options.confirmText || 'Confirm';
      // reset classes
      btnConfirm.classList.remove('danger','warning','primary');
      // map to styling classes defined in CSS
      var map = { danger: 'danger', warning: 'warning', primary: 'primary' };
      var cls = map[options.confirmClass] || 'danger';
      btnConfirm.classList.add(cls);
    }

    // show
    openOverlay();

    // handlers
    var confirmed = false;
    function onConfirmClicked(e) {
      e.preventDefault();
      confirmed = true;
      try { options.onConfirm(); } catch (err) { console.error(err); }
      cleanup();
    }
    function onCancelClicked(e) { e.preventDefault(); cleanup(); }
    function onKey(e) {
      if (e.key === 'Escape') cleanup();
    }

    function cleanup() {
      if (btnConfirm) btnConfirm.removeEventListener('click', onConfirmClicked);
      if (btnCancel) btnCancel.removeEventListener('click', onCancelClicked);
      if (btnClose) btnClose.removeEventListener('click', onCancelClicked);
      document.removeEventListener('keydown', onKey);
      // small timeout to allow visual state to settle
      setTimeout(closeOverlay, 50);
    }

    if (btnConfirm) btnConfirm.addEventListener('click', onConfirmClicked);
    if (btnCancel) btnCancel.addEventListener('click', onCancelClicked);
    if (btnClose) btnClose.addEventListener('click', onCancelClicked);
    document.addEventListener('keydown', onKey);

    return {
      close: cleanup
    };
  };

  // Auto-wire forms and links with data-confirm attributes or class 'confirm-form' / 'confirm-link'
  document.addEventListener('DOMContentLoaded', function () {
    // Forms
    document.querySelectorAll('form.confirm-form').forEach(function (form) {
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var title = form.getAttribute('data-confirm-title') || 'Please confirm';
        var message = form.getAttribute('data-confirm-message') || 'Are you sure?';
        var cls = form.getAttribute('data-confirm-class') || 'danger';
        confirmAction({
          title: title,
          message: message,
          confirmClass: cls,
          confirmText: form.getAttribute('data-confirm-confirm-text') || 'Confirm',
          onConfirm: function () { form.submit(); }
        });
      });
    });

    // Links / buttons with class confirm-link
    document.querySelectorAll('a.confirm-link, button.confirm-link').forEach(function (el) {
      el.addEventListener('click', function (e) {
        // allow anchor href navigation via callback
        e.preventDefault();
        var title = el.getAttribute('data-confirm-title') || 'Please confirm';
        var message = el.getAttribute('data-confirm-message') || 'Are you sure?';
        var cls = el.getAttribute('data-confirm-class') || 'danger';
        var href = el.getAttribute('href');
        var method = el.getAttribute('data-confirm-method') || 'get';
        confirmAction({
          title: title,
          message: message,
          confirmClass: cls,
          confirmText: el.getAttribute('data-confirm-confirm-text') || 'Confirm',
          onConfirm: function () {
            if (href) { window.location.href = href; }
            else if (method.toLowerCase() === 'post') {
              // create and submit a small POST form
              var f = document.createElement('form'); f.method = 'post'; f.action = el.getAttribute('data-confirm-action') || '#';
              var csrf = el.getAttribute('data-confirm-csrf');
              if (csrf) { var i = document.createElement('input'); i.type='hidden'; i.name='csrf_token'; i.value=csrf; f.appendChild(i); }
              document.body.appendChild(f); f.submit();
            }
          }
        });
      });
    });
  });

})();
</script>
