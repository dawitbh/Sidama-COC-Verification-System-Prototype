<?php
/*
 * Project: COC Verification system for sidama region
 * Purpose: Master's Degree Thesis 
 * * Description: This software was developed to solve a real-world problem as part of 
 * the graduation requirements for the Master's Program.
 * * Author: Dawit Birru Hurisso
 * Institution: Czech University of Life Sciences Prague (CZU)
 * Graduate Year: 2026
 */
function getCertificateStatus(?string $expiryDate, int $warningDays = 30): string {
    if (!$expiryDate) {
        return 'active';
    }

    $expiry = new DateTime($expiryDate);
    $today  = new DateTime();

    if ($expiry < $today) {
        return 'expired';
    }

    $diffDays = (int)$today->diff($expiry)->days;
    if ($diffDays <= $warningDays) {
        return 'expiring';
    }

    return 'active';
}

function renderStatusBadge(string $status, ?string $expiryDate = null): string {
    $label = ucfirst($status);
    $extra = '';

    if ($expiryDate && $status === 'expiring') {
        $today  = new DateTime();
        $expiry = new DateTime($expiryDate);
        $days   = (int)$today->diff($expiry)->days;
        $extra  = " ({$days} days left)";
    }

    switch ($status) {
        case 'expired':
            $class = 'badge bg-danger';
            break;
        case 'expiring':
            $class = 'badge bg-warning text-dark';
            break;
        default:
            $class = 'badge bg-success';
    }

    return "<span class=\"{$class}\">{$label}{$extra}</span>";
}

function csrfToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function formatDateSafe(?string $date, string $format = 'Y-m-d'): string {
    if (empty($date)) {
        return '';
    }

    // treat MySQL zero dates as empty
    if ($date === '0000-00-00' || $date === '0000-00-00 00:00:00') {
        return '';
    }

    try {
        $dt = new DateTime($date);
        return $dt->format($format);
    } catch (Exception $e) {
        return '';
    }
}

function verifyCsrfToken(?string $token): bool {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], (string)$token);
}

/**
 * Insert a row into audit_log.
 *
 * @param string $action One of CREATE, UPDATE, IMPORT, APPROVE, REVOKE, DELETE, LOGIN, LOGOUT
 * @param string|null $entity e.g. 'CERTIFICATE' or 'USER'
 * @param int|null $entityId primary id of the entity
 * @param string|null $details optional details (JSON or text)
 */
function logAudit(string $action, ?string $entity = null, $entityId = null, ?string $details = null): void {
    try {
        $dbh = getPDO();
        $userId = $_SESSION['user']['id'] ?? null;
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? null;
        if ($ip && strpos($ip, ',') !== false) { $ip = trim(explode(',', $ip)[0]); }

        $stmt = $dbh->prepare('INSERT INTO audit_log (user_id, action, entity, entity_id, details, ip_address) VALUES (:user_id, :action, :entity, :entity_id, :details, :ip_address)');
        $stmt->execute([
            ':user_id'   => $userId,
            ':action'    => $action,
            ':entity'    => $entity,
            ':entity_id' => $entityId,
            ':details'   => $details,
            ':ip_address'=> $ip,
        ]);
    } catch (Exception $e) {
        error_log('logAudit error: ' . $e->getMessage());
    }
}
