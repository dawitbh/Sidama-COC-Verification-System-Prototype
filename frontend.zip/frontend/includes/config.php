<?php
/*
 * Project: COC Verification system for sidama region
 * Purpose: Master's Degree Thesis 
 * * Description: This software was developed to solve a real-world problem as part of 
 * the graduation requirements for the Master's Program.
 * * Author: Dawit Birru Hurisso
 * Institution: Czech University of Life Sciences Prague (CZU)
 * Graduate Year: 2026
 */
// Global configuration for Sidama COC Verification System (Upgraded v2)

define('DB_HOST', 'localhost');
define('DB_NAME', 'sidamacvs');
define('DB_USER', 'root');
define('DB_PASS', '');

define('BASE_URL', '/cvst1_AI_1'); // adjust according to deployment path

// Feature flags / integrations
// Toggle availability of the external model "Claude Sonnet 4.5" for all clients.
// Set to true to enable, false to disable.
define('ENABLE_CLAUDE_SONNET', true);

// Friendly display name for UI or logs
define('CLAUDE_SONNET_NAME', 'Claude Sonnet 4.5');
