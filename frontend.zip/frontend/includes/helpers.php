<?php
/*
 * Project: COC Verification system for sidama region
 * Purpose: Master's Degree Thesis 
 * * Description: This software was developed to solve a real-world problem as part of 
 * the graduation requirements for the Master's Program.
 * * Author: Dawit Birru Hurisso
 * Institution: Czech University of Life Sciences Prague (CZU)
 * Graduate Year: 2026
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Set a flash message.
 * Types: 'success', 'error', 'warning', 'info'
 */
function setFlash(string $type, string $message): void {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (!isset($_SESSION['flash']) || !is_array($_SESSION['flash'])) {
        $_SESSION['flash'] = [];
    }
    $_SESSION['flash'][ $type ] = $message;
}

/**
 * Get and clear flash messages.
 * Returns an associative array of type => message
 */
function getFlash(): array {
    if (session_status() === PHP_SESSION_NONE) session_start();
    $f = $_SESSION['flash'] ?? [];
    if (isset($_SESSION['flash'])) unset($_SESSION['flash']);
    return is_array($f) ? $f : [];
}

/**
 * Render flash messages as Bootstrap alerts.
 */
function renderFlash(): void {
    $flashes = getFlash();
    if (empty($flashes)) return;
    foreach ($flashes as $type => $msg) {
        $class = 'alert-info';
        switch ($type) {
            case 'success': $class = 'alert-success'; break;
            case 'error': $class = 'alert-danger'; break;
            case 'danger': $class = 'alert-danger'; break;
            case 'warning': $class = 'alert-warning'; break;
            case 'info': $class = 'alert-info'; break;
        }
        // escape output
        $safe = htmlspecialchars((string)$msg);
        echo "<div class=\"alert {$class}\">{$safe}</div>\n";
    }
}

?>
